/*
Trivial blocked matrix multiply.

Written by Charles Reiss.

To the extent possible under law, I waive all copyright and related or neighboring rights 
to this file.
 */

#define _XOPEN_SOURCE 700
#include <assert.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>

// Allow easy switching between float and double
void random_matrix(long *A, int I, int J) {
    for (int i = 0; i < I; ++i) {
        for (int j = 0; j < J; ++j) {
            A[i * J + j] = lrand48();
        }
    }
}

/* computes matrix multiply C += A * B
 * A is I by K, B is K by J, C is I by J 
 */
 __attribute__((target("no-sse")))
void blocked_matmul(long * restrict A, long * restrict B, long * restrict C, int I, int K, int J) {
    assert(I % 2 == 0);
    assert(J % 2 == 0);
    assert(K % 2 == 0);
    for (int i = 0; i < I; i += 2) {
        for (int j = 0; j < J; j += 2) {
            long Ci0j0 = C[(i + 0) * J + (j + 0)];
            long Ci0j1 = C[(i + 0) * J + (j + 1)];
            long Ci1j0 = C[(i + 1) * J + (j + 0)];
            long Ci1j1 = C[(i + 1) * J + (j + 1)];
            for (int k = 0; k < K; k += 2) {
                long Ai0k0 = A[(i + 0) * K + (k + 0)];
                long Ai0k1 = A[(i + 0) * K + (k + 1)];
                long Ai1k0 = A[(i + 1) * K + (k + 0)];
                long Ai1k1 = A[(i + 1) * K + (k + 1)];
                long Bk0j0 = B[(k + 0) * J + (j + 0)];
                long Bk0j1 = B[(k + 0) * J + (j + 1)];
                long Bk1j0 = B[(k + 1) * J + (j + 0)];
                long Bk1j1 = B[(k + 1) * J + (j + 1)];

                Ci0j0 += Ai0k0 * Bk0j0 + Ai0k1 * Bk1j0;
                Ci1j0 += Ai1k0 * Bk0j0 + Ai1k1 * Bk1j0;
                Ci0j1 += Ai0k0 * Bk0j1 + Ai0k1 * Bk1j1;
                Ci1j1 += Ai1k0 * Bk0j1 + Ai1k1 * Bk1j1;
            }
            C[(i + 0) * J + (j + 0)] = Ci0j0;
            C[(i + 0) * J + (j + 1)] = Ci0j1;
            C[(i + 1) * J + (j + 0)] = Ci1j0;
            C[(i + 1) * J + (j + 1)] = Ci1j1;
        }
    }
}

uint64_t read_tsc(void) {
#ifdef __i386__
    uint32_t hi, lo;
#else
    uint64_t hi, lo;
#endif
    /* 
     * Embed the assembly instruction 'rdtsc', which should not be relocated (`volatile').
     *  The instruction will modify r_a_x and r_d_x, which the compiler should map to
     * lo and hi, respectively.
     * 
     * The format for GCC-style inline assembly generally is:
     * __asm__ ( ASSEMBLY CODE : OUTPUTS : INPUTS : OTHER THINGS CHANGED )
     *
     * Note that if you do not (correctly) specify the side effects of an assembly operation, the
     * compiler may assume that other registers and memory are not affected. This can easily
     * lead to cases where your program will produce difficult-to-debug wrong answers when
     * optimizations are enabled.
     */
    __asm__ volatile ( "rdtsc" : "=a"(lo), "=d"(hi));
#ifdef __i386__
    return lo | ((uint64_t) hi << 32);
#else
    return lo | (hi << 32);
#endif
}

#define SIZE 1024

static long A[SIZE * SIZE];
static long B[SIZE * SIZE];
static long C[SIZE * SIZE];

int main(void) {
    srand48(1); // fixed seed for reproducible results
    random_matrix(A, SIZE, SIZE);
    random_matrix(B, SIZE, SIZE);
    random_matrix(C, SIZE, SIZE);
    for (int i = 0; i < 4; ++i) {
        long start = read_tsc();
        blocked_matmul(A, B, C, SIZE, SIZE, SIZE);
        long end = read_tsc();
        printf("Iteration %d: %ld cycles\n", i, end - start);
    }
}
