#define _XOPEN_SOURCE 700
#include <stdlib.h>
#include <stdio.h>

extern void sgesv_(
    int *n,
    int *nhrs,
    float *A,
    int *lda,
    int *ipiv,
    float *B,
    int *ldb,
    int *info
);


int main() {
    int n = 1024;
    int nrhs = 128;
    float *A = malloc(n * n * sizeof(float));
    float *B = malloc(n * nrhs * sizeof(float));
    srand48(42);
    for (int i = 0; i < n * n; ++i) {
        A[i] = lrand48();
    }
    for (int i = 0; i < n * nrhs; ++i) {
        B[i] = lrand48();
    }
    int *ipiv = malloc(n * sizeof(int));
    int info = 0;
    sgesv_(&n, &nrhs, A, &n, ipiv, B, &n, &info);
    printf("info = %d\n", info);
    return 0;
}
